<?php

namespace App\Lib;

class App
{
	public static function run()
	{
		Logger::enableSystemLogs();
	}
}
