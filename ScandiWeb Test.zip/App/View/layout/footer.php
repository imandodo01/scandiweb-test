<!-- Footer -->
<footer class="page-footer">
	<hr>
	<h5 style="text-align:center;">Scandiweb Test Assignment</h5>
</footer>
<!-- Footer -->
</body>

</html>